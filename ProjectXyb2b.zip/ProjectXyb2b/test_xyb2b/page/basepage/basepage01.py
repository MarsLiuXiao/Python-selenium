'''
@Project:Python
@Time:2019/5/6 10:11
@Author:Mars/liuxiao
'''
from autodriver.autodirver001 import AutoDriver


class BasePage(object):
    def __init__(self,driver:AutoDriver):
        self.driver=driver
    # 打开浏览器
    def test_open_url(self):
        self.driver.open_url('/')
    # 清除缓存
    def test_del_cookies(self):
        self.driver.del_cookies()
    #设置时间等待
    def test_imp_wait(self):
        self.driver.test_time_wait(5)
    #关闭页面，退出浏览器
    def test_quit(self):
        self.driver.quit_bro()
    #最大化窗口
    def test_max_window(self):
        self.driver.max_window()
    # def test_xycount(self):
    #     self.driver.find_page_element('xpath','/html/body/div[1]/div/div[2]/div/div[1]/a').click()
    def test_register_btn(self):
        self.driver.find_page_element('xpath','/html/body/div[1]/div/div[1]/div[1]/div/a[2]').click()















