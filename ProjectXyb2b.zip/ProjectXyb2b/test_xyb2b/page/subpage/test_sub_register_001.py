'''
@Project:Python
@Time:2019/5/6 13:11
@Author:Mars/liuxiao
'''
from autodriver.autodirver001 import AutoDriver
from page.basepage.basepage01 import BasePage


class SubPageRegister(BasePage):
    def __init__(self,driver:AutoDriver):
        super().__init__(driver)
    #模块执行
    def test_register_module(self):
        self.driver.multi_window('next')
        self.driver.find_page_element('id','funame').send_keys('222222222')

