'''
@Project:Python
@Time:2019/5/6 9:39
@Author:Mars/liuxiao
'''
from selenium import webdriver
from selenium.webdriver import ActionChains
from selenium.webdriver.support.select import Select

class AutoDriver(object):
    def __init__(self):
        # 浏览器
        self.dirver=webdriver.Firefox()
        # 准备基地址
        self.base_url='http://www.xyb2b.com'
    #     打开网址
    def open_url(self,url):
        return self.dirver.get(self.base_url+url)
    #     窗口最大化
    def max_window(self):
        return self.dirver.maximize_window()
    def quit_bro(self):
        return self.dirver.quit()
    # 清除缓存
    def del_cookies(self):
        return self.dirver.delete_all_cookies()
    def test_time_wait(self,seconds):
        return self.dirver.implicitly_wait(seconds)
    #     定位元素
    def find_page_element(self,by,selector):
        if by=='id':
            return self.dirver.find_element_by_id(selector)
        if by=='name':
            return self.dirver.find_element_by_name(selector)
        if by=='xpath':
            return self.dirver.find_element_by_xpath(selector)
        if by=='class':
            return self.dirver.find_element_by_class_name(selector)
        if by=='link_txt':
            return  self.dirver.find_element_by_link_text(selector)
        if by=='link_part_txt':
            return self.dirver.find_element_by_partial_link_text(selector)
        if by=='css_sel':
            return self.dirver.find_element_by_css_selector(selector)
        if by=='tag':
            return self.dirver.find_element_by_tag_name(selector)
    #多表单
    def multi_frame(self,by,locate):
        if by=='next':
            return self.dirver.switch_to.frame(locate)
        if by=='back':
            return self.dirver.switch_to.parent_frame()
        if by=='first':
            return self.dirver.switch_to.default_content()
    #多窗口句柄
    def multi_window(self,by):
        if by=='next':
            all_window_handles= self.dirver.window_handles
            for handle in all_window_handles:
                if handle==self.dirver.current_window_handle:
                    handle=all_window_handles[1]
                return self.dirver.switch_to.window(handle)

    #下拉菜单
    def select_box(self,by,find_mode,selector,value):
        if by=='index':
            return Select(self.find_page_element(find_mode,selector)).select_by_index(value)
        if by=='val':
            return Select(self.find_page_element(find_mode,selector)).select_by_value(value)
        if by=='vi_txt':
            return Select(self.find_page_element(find_mode,selector)).select_by_visible_text(value)
    #悬停
    def hover_ele(self,by):
        if by=='id':
            ActionChains(self.dirver).move_to_element(self.dirver.find_element()).perform()