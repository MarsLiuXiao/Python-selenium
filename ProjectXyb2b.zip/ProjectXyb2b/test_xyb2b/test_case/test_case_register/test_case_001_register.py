'''
@Project:Python
@Time:2019/5/6 9:37
@Author:Mars/liuxiao
'''
import unittest
import time

from selenium import webdriver

from autodriver.autodirver001 import AutoDriver
from page.subpage.test_sub_register_001 import SubPageRegister


class TestRegister(unittest.TestCase):
    def setUp(self):
        self.driver=AutoDriver()
        self.sub=SubPageRegister(self.driver)
        self.sub.test_max_window()
        self.sub.test_del_cookies()
        self.sub.test_imp_wait()
    def tearDown(self):
        #关闭页面，退出浏览器驱动
        self.sub.test_quit()
    def test_register(self):
        self.sub.test_open_url()
        self.sub.test_register_btn()
        self.sub.test_register_module()
        time.sleep(5)
        