import unittest
# 测试套件
from test_case.test_ecshop_login_001 import TestEcshopLogin
from test_case.test_login import test_ecshop_login_001
from test_case.test_messge import test_ecshop_message_003

if __name__=='__main__':
    # 构造测试集
    suite=unittest.TestSuite()
    # 添加测试用例（类名+测试方法名）
    # suite.addTest(TestCase001Login('test_login'))
    suite.addTest(unittest.makeSuite(TestEcshopLogin))
    suite.addTest(unittest.makeSuite(test_ecshop_message_003.TestMessage))

    # 运行测试集合
    runner=unittest.TextTestRunner()
    runner.run(suite)