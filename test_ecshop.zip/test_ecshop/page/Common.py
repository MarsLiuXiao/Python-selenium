'''
@Project:Python
@Time:2019/5/3 10:15
@Author:Mars/liuxiao
'''
from selenium.webdriver.support.select import Select
from AutoDriver.AutoDriver_001 import AutoDriver
import time
class Common(object):
    def __init__(self,driver:AutoDriver):
        self.driver=driver
        #使用时，可看作是类的"引用"，没有对类进行实例化,定义公共类时.

    # 初始化界面，清除缓存
    def test_initialui(self):
        self.driver.max_window()
        self.driver.del_cookies()
    def test_bro_back(self):
        self.driver.bro_back()
    def test_open_url(self):
        self.driver.open_url('/')
    # 退出浏览器
    def test_quitbro(self):
        self.driver.quit_brower()
    # 定位到登录按钮
    def test_login_btn(self):

        self.driver.find_element('xpath','/html/body/div[1]/div[2]/ul/li[1]/font/a[1]/img').click()
        time.sleep(1)

    # 登录模块
    def test_login(self):
        # 定位到用户名输入框并传值
        self.driver.find_element('name','username').send_keys('liuxiao')
        #定位到密码输入框传值
        self.driver.find_element('name','password').send_keys('123456')
        # 定位到选择框并点击
        self.driver.find_element('id','remember').click()
        time.sleep(1)
        # 定位到立即登录按钮并点击
        self.driver.find_element('name','submit').click()
        time.sleep(1)
    # search box搜索模块
    def test_search(self):
        self.driver.find_element('id','keyword').send_keys('N96')
        # click search button
        self.driver.find_element('xpath','/html/body/div[4]/form/input[2]').click()
        time.sleep(2)
    #购买点击
    def test_buy_btn(self):
        self.driver.find_element('xpath','/html/body/div[7]/div[2]/div[1]/div/form/div/div/div/a[3]').click()
        time.sleep(1)
        self.driver.find_element('xpath','/html/body/div[16]/center/a[1]').click()
        time.sleep(2)
    #购买数量设定
    def test_buy_num(self):
         # self.driver.find_element_by_xpath('/html/body/div[7]/div[1]/form/table[1]/tbody/tr[2]/td[5]/input').click()#可以不点击
        time.sleep(1)
        self.driver.find_element('xpath','/html/body/div[7]/div[1]/form/table[1]/tbody/tr[2]/td[5]/input').clear()
        time.sleep(2)
        self.driver.find_element('xpath','/html/body/div[7]/div[1]/form/table[1]/tbody/tr[2]/td[5]/input').send_keys(3)
        self.driver.find_element('xpath','/html/body/div[7]/div[1]/table/tbody/tr/td[2]/a/img').click()

    def test_acp_add(self):
        Select(self.driver.find_element('id','selCountries_0')).select_by_value('1')
        time.sleep(1)
        Select(self.driver.find_element('xpath','/html/body/div[7]/form/div/table/tbody/tr[1]/td[2]/select[2]')).select_by_value('30')
        time.sleep(1)
        Select(self.driver.find_element('xpath','/html/body/div[7]/form/div/table/tbody/tr[1]/td[2]/select[3]')).select_by_value('367')
        time.sleep(1)
        Select(self.driver.find_element('xpath','/html/body/div[7]/form/div/table/tbody/tr[1]/td[2]/select[4]')).select_by_value('3100')
        time.sleep(1)
        self.driver.find_element('id','consignee_0').send_keys('lx')
        self.driver.find_element('id','address_0').send_keys('云南昆明')
        self.driver.find_element('id','tel_0').send_keys('13587041124')
        self.driver.find_element('name','Submit').click()
    # 选择支付方式并点击
    def test_pay_mode(self):
        self.driver.find_element('xpath','/html/body/div[7]/form/div[5]/table/tbody/tr[2]/td[1]/input').click()
        time.sleep(1)
        self.driver.find_element('xpath','/html/body/div[7]/form/div[7]/table/tbody/tr[4]/td[1]/input').click()
        time.sleep(1)
        self.driver.find_element('xpath','/html/body/div[7]/form/div[7]/table/tbody/tr[3]/td[1]/input').click()
        time.sleep(1)
        self.driver.find_element('xpath','/html/body/div[7]/form/div[15]/div[2]/input[1]').click()
        time.sleep(1)
    #     用户中心
    def test_usr_cen_btn(self):
        # 点击用户中心
        self.driver.find_element('xpath','/html/body/div[1]/div[2]/ul/li[1]/font/font/a[1]').click()


    def test_message_module(self,theme,content):

        # 点击我的留言
        self.driver.find_element('xpath','/html/body/div[7]/div[1]/div/div/div/div/a[6]').click()
        # 定位留言
        self.driver.find_element('xpath','/html/body/div[7]/div[2]/div/div/div/form/table/tbody/tr[1]/td[2]/input[1]').click()
        # 定位主题
        self.driver.find_element('xpath','/html/body/div[7]/div[2]/div/div/div/form/table/tbody/tr[2]/td[2]/input').send_keys(theme)
        # 定位留言内容
        self.driver.find_element('name','msg_content').send_keys(content)
        # 上传文件
        self.driver.find_element('name','message_img').send_keys(r'C:\Users\EDZ\Desktop\001\a.txt')
        # 提交
        self.driver.find_element('xpath','/html/body/div[7]/div[2]/div/div/div/form/table/tbody/tr[5]/td[2]/input[2]').click()

    def test_personinfo_module(self):
        self.driver.find_element('xpath','/html/body/div[7]/div[1]/div/div/div/div/a[2]').click()
        # Select(self.driver.find_element('name','birthdayYear')).select_by_value('2001')
        # Select(self.driver.find_element('name','birthdayMonth')).select_by_value('7')
        # Select(self.driver.find_element('name','birthdayDay')).select_by_value('6')
        self.driver.select_box('value','name','birthdayYear','2001')
        self.driver.select_box('value','name','birthdayMonth','7')
        self.driver.select_box('value','name','birthdayDay','6')

        self.driver.find_element('xpath','/html/body/div[7]/div[2]/div/div/div/form[1]/table/tbody/tr[2]/td[2]/input[2]').click()
        self.driver.find_element('name','email').clear()
        self.driver.find_element('name','extend_field1').clear()
        self.driver.find_element('name','extend_field2').clear()
        self.driver.find_element('name','extend_field3').clear()
        self.driver.find_element('name','extend_field4').clear()
        self.driver.find_element('name','extend_field5').clear()
        self.driver.find_element('name','email').send_keys('liu123@qq.com')
        self.driver.find_element('name','extend_field1').send_keys('liuxiao@qq.com')
        self.driver.find_element('name','extend_field2').send_keys('1234566')
        self.driver.find_element('name','extend_field3').send_keys('7878778')
        self.driver.find_element('name','extend_field4').send_keys('7878778')
        self.driver.find_element('name','extend_field5').send_keys('15909009909')
        # Select(self.driver.find_element('name','sel_question')).select_by_value('favorite_song')
        self.driver.select_box('value','name','sel_question','favorite_song')
        self.driver.find_element('name','passwd_answer').send_keys("nobody can success without effort")
        self.driver.find_element('name','submit').click()
        time.sleep(1)
    def safe_quit(self):
        # 定位安全退出按钮并点击
        self.driver.find_element('xpath','/html/body/div[7]/div[1]/div/div/div/div/a[14]/img').click()