'''
@Project:Python
@Time:2019/5/4 14:16
@Author:Mars/liuxiao
'''
from AutoDriver.AutoDriver_001 import AutoDriver
from page.base_package.base_page import BasePage


class SubPageUserRegister(BasePage):
    def __init__(self,driver:AutoDriver):
        super().__init__(driver)