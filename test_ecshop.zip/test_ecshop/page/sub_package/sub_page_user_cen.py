'''
@Project:Python
@Time:2019/5/3 17:58
@Author:Mars/liuxiao
'''
from AutoDriver.AutoDriver_001 import AutoDriver
from page.base_package.base_page import BasePage


class SubPageUserCen(BasePage):
    def __init__(self,driver:AutoDriver):
        super().__init__(driver)

    def safe_quit(self):
        # 定位安全退出按钮并点击
        self.driver.find_element('xpath','/html/body/div[7]/div[1]/div/div/div/div/a[14]/img').click()
    def test_message_module(self,theme,content):
        # 点击我的留言
        self.driver.find_element('xpath','/html/body/div[7]/div[1]/div/div/div/div/a[6]').click()
        # 定位留言
        self.driver.find_element('xpath','/html/body/div[7]/div[2]/div/div/div/form/table/tbody/tr[1]/td[2]/input[1]').click()
        # 定位主题
        self.driver.find_element('xpath','/html/body/div[7]/div[2]/div/div/div/form/table/tbody/tr[2]/td[2]/input').send_keys(theme)
        # 定位留言内容
        self.driver.find_element('name','msg_content').send_keys(content)
        # 上传文件
        self.driver.find_element('name','message_img').send_keys(r'C:\Users\EDZ\Desktop\001\a.txt')
        # 提交
        self.driver.find_element('xpath','/html/body/div[7]/div[2]/div/div/div/form/table/tbody/tr[5]/td[2]/input[2]').click()
