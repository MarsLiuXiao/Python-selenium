'''
@Project:Python
@Time:2019/5/3 17:49
@Author:Mars/liuxiao
'''
#继承AutoDriver
from AutoDriver.AutoDriver_001 import AutoDriver
import time

class BasePage(object):
    def __init__(self,driver:AutoDriver):
        self.driver=driver

    def test_login_btn(self):
        self.driver.find_element('xpath','/html/body/div[1]/div[2]/ul/li[1]/font/a[1]/img').click()
        time.sleep(1)
    # 登录模块
    def test_login(self,username,passwd):
        # 定位到用户名输入框并传值
        self.driver.find_element('name','username').send_keys(username)
        #定位到密码输入框传值
        self.driver.find_element('name','password').send_keys(passwd)
        # 定位到选择框并点击
        self.driver.find_element('id','remember').click()
        time.sleep(1)
        # 定位到立即登录按钮并点击
        self.driver.find_element('name','submit').click()
        time.sleep(1)
    def test_usr_cen_btn(self):
        # 点击用户中心
        self.driver.find_element('xpath','/html/body/div[1]/div[2]/ul/li[1]/font/font/a[1]').click()
