'''
@Project:Python
@Time:2019/4/29 14:33
@Author:Mars/liuxiao
'''

import time
from AutoDriver.AutoDriver_001 import AutoDriver
# # 浏览器实例化
# driver=webdriver.Firefox()
# # 打开url
# driver.get('http://localhost/wamp/www/ECShop_V2.7.2_b03/upload/')#暂停显示
# driver.maximize_window()
# time.sleep(1)
# # 点击注册按钮
# driver.find_element_by_xpath('/html/body/div[1]/div[2]/ul/li[1]/font/a[2]/img').click()
# # 用户名
# driver.find_element_by_id('username').send_keys('liuxiao')
# # email
# driver.find_element_by_id('email').send_keys('liu123@qq.com')
# # 密码
# driver.find_element_by_id('password1').send_keys('123456')
#
# # 确认密码
# driver.find_element_by_id('conform_password').send_keys('123456')
# # MSN
# driver.find_element_by_name('extend_field1').send_keys('liu12345@qq.com')
# # QQ
# driver.find_element_by_name('extend_field2').send_keys('1234567')
# # 办公电话
# driver.find_element_by_name('extend_field3').send_keys('0870356')
# # 家庭电话
# driver.find_element_by_name('extend_field4').send_keys('0870356')
# # 手机
# driver.find_element_by_name('extend_field5').send_keys('13666666666')
# # 密码提示问题
# # *******************************
# Select(driver.find_element_by_name('sel_question')).select_by_value('motto')
# # 密码问题答案
# driver.find_element_by_name('passwd_answer').send_keys('世界不在书里和地图上，是走出来的！')
# # 立即注册按钮
# driver.find_element_by_name('Submit').click()
# time.sleep(4)
# driver.close()



# import unittest
# class TestEcshopRegiter(unittest.TestCase):
#     def setUp(self):
#         # url
#         self.url='http://localhost/wamp/www/ECShop_V2.7.2_b03/upload/'
#         # 浏览器
#         self.driver=webdriver.Firefox()
#         # 全屏
#         self.driver.maximize_window()
#         # 清除所有缓存
#         self.driver.delete_all_cookies()
#     def tearDown(self):
#         # 退出浏览器
#         self.driver.quit()
#     def test_ecshop_register_001(self):
#         self.driver.get(self.url)
#         self.driver.find_element_by_xpath('/html/body/div[1]/div[2]/ul/li[1]/font/a[2]/img').click()
#         # 用户名
#         self.driver.find_element_by_id('username').send_keys('liuxiao')
#          # email
#         self.driver.find_element_by_id('email').send_keys('liu123@qq.com')
#         # 密码
#         self.driver.find_element_by_id('password1').send_keys('123456')
#
#         # 确认密码
#         self.driver.find_element_by_id('conform_password').send_keys('123456')
#         # MSN
#         self.driver.find_element_by_name('extend_field1').send_keys('liu12345@qq.com')
#         # QQ
#         self.driver.find_element_by_name('extend_field2').send_keys('1234567')
#         # 办公电话
#         self.driver.find_element_by_name('extend_field3').send_keys('0870356')
#         # 家庭电话
#         self.driver.find_element_by_name('extend_field4').send_keys('0870356')
#         # 手机
#         self.driver.find_element_by_name('extend_field5').send_keys('13666666666')
#         # 密码提示问题
#         # *******************************
#         Select(self.driver.find_element_by_name('sel_question')).select_by_value('motto')
#         # 密码问题答案
#         self.driver.find_element_by_name('passwd_answer').send_keys('世界不在书里和地图上，是走出来的！')
#         # 立即注册按钮
#         time.sleep(5)
#         self.driver.find_element_by_name('Submit').click()
#         time.sleep(4)
driver=AutoDriver()
import unittest
class TestEcshopRegister(unittest.TestCase):

    def setUp(self):
        # 全屏
        self.driver=AutoDriver()
        self.driver.max_window()
        # 清除所有缓存
        self.driver.del_cookies()
    def tearDown(self):
        # 退出浏览器
        self.driver.quit_brower()
    def test_ecshop_register_001(self):
        self.driver.open_url('/')
        self.driver.find_element('xpath','/html/body/div[1]/div[2]/ul/li[1]/font/a[2]/img').click()
        # 用户名
        self.driver.find_element('id','username').send_keys('liuxiao')
         # email
        self.driver.find_element('id','email').send_keys('liu123@qq.com')
        # 密码
        self.driver.find_element('id','password1').send_keys('123456')
        # 确认密码
        self.driver.find_element('id','conform_password').send_keys('123456')
        # MSN
        self.driver.find_element('name','extend_field1').send_keys('liu12345@qq.com')
        # QQ
        self.driver.find_element('name','extend_field2').send_keys('1234567')
        # 办公电话
        self.driver.find_element('name','extend_field3').send_keys('0870356')
        # 家庭电话
        self.driver.find_element('name','extend_field4').send_keys('0870356')
        # 手机
        self.driver.find_element('name','extend_field5').send_keys('13666666666')
        # 密码提示问题
        # *******************************
        # Select(self.driver.find_element_by_name('sel_question')).select_by_value('motto')
        self.driver.select_box('value','name','sel_question','motto')
        # 密码问题答案
        time.sleep(5)
        self.driver.find_element('name','passwd_answer').send_keys('世界不在书里和地图上，是走出来的！')
        # 立即注册按钮
        time.sleep(5)
        self.driver.find_element('name','Submit').click()
        time.sleep(4)
