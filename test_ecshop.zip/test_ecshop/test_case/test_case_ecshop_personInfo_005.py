'''
@Project:Python
@Time:2019/4/29 18:24
@Author:Mars/liuxiao
'''
import time

# 浏览器实例化
from selenium.webdriver.support.select import Select



# driver=webdriver.Firefox()
# driver.maximize_window()
# #打开url
# driver.get('http://localhost/wamp/www/ECShop_V2.7.2_b03/upload/')
# time.sleep(1)
# # 定位到登录按钮并点击
# driver.find_element_by_xpath('/html/body/div[1]/div[2]/ul/li[1]/font/a[1]/img').click()
# time.sleep(1)
# # 定位到用户名输入框并传值
# driver.find_element_by_name('username').send_keys('liuxiao')
# #定位到密码输入框传值
# driver.find_element_by_name('password').send_keys('123456')
# # 定位到选择框并点击
# driver.find_element_by_id('remember').click()
# time.sleep(1)
# # 定位到立即登录按钮并点击
# driver.find_element_by_name('submit').click()
# time.sleep(1)
# driver.find_element_by_xpath('/html/body/div[1]/div[2]/ul/li[1]/font/font/a[1]').click()
# time.sleep(1)
# # 点击用户信息
# driver.find_element_by_xpath('/html/body/div[7]/div[1]/div/div/div/div/a[2]').click()
# Select(driver.find_element_by_name('birthdayYear')).select_by_value('2001')
# Select(driver.find_element_by_name('birthdayMonth')).select_by_value('7')
# Select(driver.find_element_by_name('birthdayDay')).select_by_value('6')
# driver.find_element_by_xpath('/html/body/div[7]/div[2]/div/div/div/form[1]/table/tbody/tr[2]/td[2]/input[2]').click()
# driver.find_element_by_name('email').clear()
# driver.find_element_by_name('extend_field1').clear()
# driver.find_element_by_name('extend_field2').clear()
# driver.find_element_by_name('extend_field3').clear()
# driver.find_element_by_name('extend_field4').clear()
# driver.find_element_by_name('extend_field5').clear()
# driver.find_element_by_name('email').send_keys('liu123@qq.com')
# driver.find_element_by_name('extend_field1').send_keys('liuxiao@qq.com')
# driver.find_element_by_name('extend_field2').send_keys('1234566')
# driver.find_element_by_name('extend_field3').send_keys('7878778')
# driver.find_element_by_name('extend_field4').send_keys('7878778')
# driver.find_element_by_name('extend_field5').send_keys('15909009909')
# Select(driver.find_element_by_name('sel_question')).select_by_value('favorite_song')
# driver.find_element_by_name('passwd_answer').send_keys("nobody can success without effort")
# driver.find_element_by_name('submit').click()
# time.sleep(2)

# 导入单元测试模组
import unittest
# 导入AutoDriver、Common类
from AutoDriver.AutoDriver_001 import AutoDriver
from page.Common import Common
# 使用单元测试框架
class TestPersonInfo(unittest.TestCase):
    def setUp(self):
        self.driver=AutoDriver()
        self.com_fun=Common(self.driver)
        # 浏览器操作：最大化和清除缓存
        self.com_fun.test_initialui()
    def tearDown(self):
        # 退出浏览器驱动
        self.com_fun.test_quitbro()
    def test_perinfo(self):
        #打开url
        self.com_fun.open_url()
        self.com_fun.test_login_btn()
        self.com_fun.test_login()
        self.com_fun.test_usr_cen_btn()
        time.sleep(2)
        self.com_fun.test_personinfo_module()































