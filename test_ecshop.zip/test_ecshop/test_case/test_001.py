'''
@Project:Python
@Time:2019/4/29 17:35
@Author:Mars/liuxiao
'''
import time

# # 实例化浏览器
# from selenium.webdriver.common.keys import Keys
#
# from AutoDriver.AutoDriver_001 import AutoDriver
# from page.Common import Common
# ad=AutoDriver()
# c=Common(ad)
# driver=ad
#
# # 打开url
#
# driver.open_url('/')
# time.sleep(1)
# # 全屏
# driver.max_window()
# # 搜索框
# # # 获取当前页面句柄
# # current_window_handle=driver.current_window_handle
# # # 获取所有的页面句柄
# # all_window_handles=driver.window_handles
# # for handle in all_window_handles:
# #     if handle!=current_window_handle:
# #         driver.switch_to.window(handle)
# driver.find_element('id','search_shopping').send_keys('洗面奶')
# #点击搜索按钮
# driver.find_element('id','search_btn').click()
from selenium import webdriver
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By

from selenium.webdriver.support import expected_conditions as EC

from selenium.webdriver.support.wait import WebDriverWait

# driver=webdriver.Firefox()
# driver.get("http://www.baidu.com")
# driver.maximize_window()
# driver.delete_all_cookies()

# 使用contains：格式为：//标签名[contains(@属性名,)]
# driver.find_element_by_xpath("//a[contains(@href,'http://xueshu.')]").click()
# driver.find_element_by_xpath("//a[starts-with(@href,'http://xueshu.')]").click()
# located1=driver.find_element(By.ID,'kw')
# WebDriverWait(driver,5,0.5).until(EC.presence_of_element_located(located1))
#
# driver.find_element_by_xpath("//*[text()='学术']").click()
# driver.find_element(By.XPATH,'/html/body/div[2]/div[2]/div[3]/div[4]/div/div[1]')

# a=driver.find_element(By.XPATH,'/html/body/div[1]/div[1]/div/div[3]/a[8]')#定位不到
# time.sleep(1)
# ActionChains(driver).move_to_element(a).perform()
# time.sleep(1)
# driver.close()

# for i in range(1,10):
#     for j in range(1,10):
#         if j<=i:
#             print(j,'*',i,'=',i*j,end='   ')
#     print()
# a,b temp
# temp=a   a赋值给temp
#a=b
#b=temp 假设第一个值为最大值，max 第一个值与第二个值交换

def bubbleSort(nums):
    for i in range(len(nums)-1):
        for j in range(len(nums)-i-1):
            if nums[j]>nums[j+1]:
                nums[j],nums[j+1]=nums[j+1],nums[j]

    return nums
nums=[8,7,9,10,6]
print(bubbleSort(nums))
# def bubbleSort(nums):
#     for i in range(len(nums)-1):    # 这个循环负责设置冒泡排序进行的次数
#         for j in range(len(nums)-i-1):  # ｊ为列表下标
#             if nums[j] > nums[j+1]:
#                 nums[j], nums[j+1] = nums[j+1], nums[j]
#     return nums
#
# nums = [5,2,45,6,8,2,1]
#
# print (bubbleSort(nums))
