'''
@Project:Python
@Time:2019/4/29 15:41
@Author:Mars/liuxiao
'''
import time
from selenium import webdriver
# 实例化浏览器
from selenium.webdriver.common.keys import Keys

driver=webdriver.Firefox()
# 打开url
driver.get('http://www.xyb2b.com/')
# 全屏
driver.maximize_window()
# 定位登录按钮
driver.find_element_by_xpath('/html/body/div[1]/div/div[1]/div[1]/div/a[1]').click()
#
# # 第一种方法
# # 1.获取当前窗口句柄
# current_window_handle=driver.current_window_handle
# # 2.获取所有窗体句柄
# all_window_handles=driver.window_handles
# # 3.遍历当前的窗口句柄
# for handle in all_window_handles:
#     if handle !=current_window_handle:
#         driver.switch_to.window(handle)
#
# #
# 第二种方法
# 1.获取所有的窗口句柄
all_window_handles=driver.window_handles
driver.switch_to.window(all_window_handles[1])
# 用户名
driver.find_element_by_id('userName').send_keys(Keys.F1)
time.sleep(4)
# 密码
driver.find_element_by_id('password').send_keys('123456')
# 选中自动登录
driver.find_element_by_xpath('/html/body/div[2]/div[2]/div/form/div[4]/label/em').click()
# 点击登录
driver.find_element_by_id('loginBtn').click()
time.sleep(5)
driver.close()