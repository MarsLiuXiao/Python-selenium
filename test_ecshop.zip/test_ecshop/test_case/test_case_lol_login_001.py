'''
@Project:Python
@Time:2019/4/29 15:51
@Author:Mars/liuxiao
'''
import time
from selenium import webdriver
from selenium.webdriver.common.by import By
# 实例化浏览器
from AutoDriver.AutoDriver_001 import AutoDriver
driver=AutoDriver()#实例化对象
driver.open_url('/')
driver.max_window()
time.sleep(2)

driver.find_element('xpath','/html/body/div[1]/div[1]/div[1]/div[2]/p[1]/a').click()
# 多表单切换*********

# driver.switch_to.frame('loginIframe')#使用封装的方法实现
driver.multi_frame('direct','loginIframe')

driver.find_element('id','switcher_plogin').click()
driver.find_element('id','u').send_keys('54497727')
driver.find_element('id','p').send_keys('qqqeee')
# driver.find_element_by_id('login_button').click()
time.sleep(2)




