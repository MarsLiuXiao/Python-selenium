'''
@Project:Python
@Time:2019/4/29 19:39
@Author:Mars/liuxiao
'''
# 登录ECShop---首页诺基亚N96---点击购买---点击购买---修改数量为3---结算---配送至这个地址
import time
from selenium import webdriver
from selenium.webdriver.common.by import By

from selenium.webdriver.support.select import Select
# brower
# driver=webdriver.Firefox()
# # open url
# driver.get('http://localhost/wamp/www/ECShop_V2.7.2_b03/upload/')
# time.sleep(1)
# # max form
# driver.maximize_window()
# # 定位到登录按钮并点击
# driver.find_element_by_xpath('/html/body/div[1]/div[2]/ul/li[1]/font/a[1]/img').click()
# time.sleep(1)
# # 定位到用户名输入框并传值
# driver.find_element_by_name('username').send_keys('liuxiao')
# #定位到密码输入框传值
# driver.find_element_by_name('password').send_keys('123456')
# # 定位到选择框并点击
# driver.find_element_by_id('remember').click()
# time.sleep(1)
# # 定位到立即登录按钮并点击
# driver.find_element_by_name('submit').click()
# # search box
# driver.find_element_by_id('keyword').send_keys('N96')
# # click search button
# driver.find_element_by_xpath('/html/body/div[4]/form/input[2]').click()
# #click buy button
# driver.find_element_by_xpath('/html/body/div[7]/div[2]/div[1]/div/form/div/div/div/a[3]').click()
# time.sleep(1)
# driver.find_element_by_xpath('/html/body/div[16]/center/a[1]').click()
# # alter
# time.sleep(1)
# # driver.find_element_by_xpath('/html/body/div[7]/div[1]/form/table[1]/tbody/tr[2]/td[5]/input').click()
# driver.find_element_by_xpath('/html/body/div[7]/div[1]/form/table[1]/tbody/tr[2]/td[5]/input').clear()
# driver.find_element_by_xpath('/html/body/div[7]/div[1]/form/table[1]/tbody/tr[2]/td[5]/input').send_keys(3)
# driver.find_element_by_xpath('/html/body/div[7]/div[1]/table/tbody/tr/td[2]/a/img').click()
# try:
#     Select(driver.find_element_by_id('selCountries_0')).select_by_value('1')
#     time.sleep(1)
#     Select(driver.find_element_by_xpath('/html/body/div[7]/form/div/table/tbody/tr[1]/td[2]/select[2]')).select_by_value('30')
#     time.sleep(1)
#     Select(driver.find_element_by_xpath('/html/body/div[7]/form/div/table/tbody/tr[1]/td[2]/select[3]')).select_by_value('367')
#     time.sleep(1)
#     Select(driver.find_element_by_xpath('/html/body/div[7]/form/div/table/tbody/tr[1]/td[2]/select[4]')).select_by_value('3100')
#     time.sleep(1)
#     driver.find_element_by_id('consignee_0').send_keys('lx')
#     driver.find_element_by_id('address_0').send_keys('云南昆明')
#     driver.find_element_by_id('tel_0').send_keys('13587041124')
#     driver.find_element_by_name('Submit').click()
# except:
#     pass
#
# finally:
#     driver.find_element_by_xpath('/html/body/div[7]/form/div[5]/table/tbody/tr[2]/td[1]/input').click()
#     time.sleep(1)
#     driver.find_element_by_xpath('/html/body/div[7]/form/div[7]/table/tbody/tr[4]/td[1]/input').click()
#     time.sleep(1)
#     driver.find_element_by_xpath('/html/body/div[7]/form/div[7]/table/tbody/tr[3]/td[1]/input').click()
#     time.sleep(1)
#     driver.find_element_by_xpath('/html/body/div[7]/form/div[15]/div[2]/input[1]').click()
#     time.sleep(1)
#     driver.quit()

import  unittest
from AutoDriver.AutoDriver_001 import AutoDriver
from page.Common import Common

class TestEcshopCommodity(unittest.TestCase):
    def setUp(self):
        # 浏览器
        self.driver=AutoDriver()
        self.com_fun=Common(self.driver)#**************实例化Common类
        self.com_fun.test_initialui()

        # self.driver.max_window()
        # # 释放缓存
        # self.driver.del_cookies()
    def tearDown(self):
        #关闭所有页面、并关闭浏览器。close()关闭当前页面
        self.com_fun.test_quitbro()
        # self.driver.quit_brower()
    def test_case_ecshop_commodity001(self):
        self.driver.open_url('/')
        # 定位到登录按钮并点击
        # self.driver.find_element('xpath','/html/body/div[1]/div[2]/ul/li[1]/font/a[1]/img').click()

        self.com_fun.test_login_btn()
        time.sleep(1)

        # # 定位到用户名输入框并传值
        # self.driver.find_element('name','username').send_keys('liuxiao')
        # #定位到密码输入框传值
        # self.driver.find_element('name','password').send_keys('123456')
        # # 定位到选择框并点击
        # self.driver.find_element('id','remember').click()
        # time.sleep(1)
        # # 定位到立即登录按钮并点击
        # self.driver.find_element('name','submit').click()

        self.com_fun.test_login()


        # search box

        # self.driver.find_element('id','keyword').send_keys('N96')
        # # click search button
        # self.driver.find_element('xpath','/html/body/div[4]/form/input[2]').click()

        self.com_fun.test_search()
        #click buy button
        # /html/body/div[7]/div[2]/div[1]/div/form/div/div/div/a[3]

        # self.driver.find_element('xpath','/html/body/div[7]/div[2]/div[1]/div/form/div/div/div/a[3]').click()
        # time.sleep(1)
        # self.driver.find_element('xpath','/html/body/div[16]/center/a[1]').click()
        self.com_fun.test_buy_btn()
        # alter div

        # # self.driver.find_element_by_xpath('/html/body/div[7]/div[1]/form/table[1]/tbody/tr[2]/td[5]/input').click()

        # self.driver.find_element('xpath','/html/body/div[7]/div[1]/form/table[1]/tbody/tr[2]/td[5]/input').clear()

        # self.driver.find_element('xpath','/html/body/div[7]/div[1]/form/table[1]/tbody/tr[2]/td[5]/input').send_keys(3)

        # self.driver.find_element('xpath','/html/body/div[7]/div[1]/table/tbody/tr/td[2]/a/img').click()
        self.com_fun.test_buy_num()
        try:
            # # Select(self.driver.find_element('id','selCountries_0')).select_by_value('1')
            # time.sleep(1)
            # # Select(self.driver.find_element('xpath','/html/body/div[7]/form/div/table/tbody/tr[1]/td[2]/select[2]')).select_by_value('30')
            # time.sleep(1)
            # # Select(self.driver.find_element('xpath','/html/body/div[7]/form/div/table/tbody/tr[1]/td[2]/select[3]')).select_by_value('367')
            # time.sleep(1)
            # # Select(self.driver.find_element('xpath','/html/body/div[7]/form/div/table/tbody/tr[1]/td[2]/select[4]')).select_by_value('3100')
            # time.sleep(1)
            self.com_fun.test_aacp_add()
            # self.driver.find_element('id','consignee_0').send_keys('lx')
            # self.driver.find_element('id','address_0').send_keys('云南昆明')
            # self.driver.find_element('id','tel_0').send_keys('13587041124')
            # 点击提交
            # self.driver.find_element('name','Submit').click()

        except:
            pass

        finally:
            self.com_fun.test_pay_mode()
            # self.driver.find_element('xpath','/html/body/div[7]/form/div[5]/table/tbody/tr[2]/td[1]/input').click()
            # time.sleep(1)
            # self.driver.find_element('xpath','/html/body/div[7]/form/div[7]/table/tbody/tr[4]/td[1]/input').click()
            # time.sleep(1)
            # self.driver.find_element('xpath','/html/body/div[7]/form/div[7]/table/tbody/tr[3]/td[1]/input').click()
            # time.sleep(1)
            # self.driver.find_element('xpath','/html/body/div[7]/form/div[15]/div[2]/input[1]').click()
            # time.sleep(1)
