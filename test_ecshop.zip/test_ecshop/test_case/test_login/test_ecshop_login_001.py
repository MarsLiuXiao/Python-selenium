'''
@Project:Python
@Time:2019/4/29 11:33
@Author:Mars/liuxiao
'''
# 打开url--点击登录按钮--点击用户名输入框传值--点击密码输入框传值--点击选择框--点击立即登录
# 点击用户中心--点击安全退出
import csv

from selenium import webdriver
import time
# # 浏览器实例化
# driver=webdriver.Firefox()
# #打开url
# driver.get('http://localhost/wamp/www/ECShop_V2.7.2_b03/upload/')
# time.sleep(1)
# # 定位到登录按钮并点击
# driver.find_element_by_xpath('/html/body/div[1]/div[2]/ul/li[1]/font/a[1]/img').click()
# time.sleep(1)
# # 定位到用户名输入框并传值
# driver.find_element_by_name('username').send_keys('Lmars')
# #定位到密码输入框传值
# driver.find_element_by_name('password').send_keys('123456')
# # 定位到选择框并点击
# driver.find_element_by_id('remember').click()
# time.sleep(1)
# # 定位到立即登录按钮并点击
# driver.find_element_by_name('submit').click()
# time.sleep(1)
# # 定位到用户中心点击
# driver.find_element_by_xpath('/html/body/div[1]/div[2]/ul/li[1]/font/font/a[1]').click()
# time.sleep(1)
# #定位到安全退出并点击
# driver.find_element_by_xpath('/html/body/div[7]/div[1]/div/div/div/div/a[14]/img').click()
# time.sleep(1)


# # 使用单元测试框架
import unittest

from AutoDriver.AutoDriver_001 import AutoDriver
from page.base_package.base_page import BasePage
from page.sub_package.sub_page_user_cen import SubPageUserCen

class TestEcshopLogin(unittest.TestCase):
    '''这是登录模块测试'''


    def setUp(self):
        self.driver=AutoDriver()
        # self.bp=BasePage(self.driver)
        self.sub=SubPageUserCen(self.driver)
        self.driver.max_window()
        self.driver.del_cookies()

    def tearDown(self):
        # 关闭浏览器
        self.driver.quit_brower()

    def test_ecshop_login_001(self):
        self.driver.open_url('/')
        csv_file=open(r'C:\Users\EDZ\PycharmProjects\test_ecshop\data\login_data.csv',mode='r',encoding='utf8')
        csv_date=csv.reader(csv_file)
        for i in csv_date:
            login_dict={
                'username':i[0],
                'passwd':i[1]
            }
            # 登陆按钮
            self.sub.test_login_btn()
            self.sub.test_login(login_dict['username'],login_dict['passwd'])
            # 定位到登录按钮并点击
            # self.driver.find_element_by_xpath('/html/body/div[1]/div[2]/ul/li[1]/font/a[1]/img').click()
            # time.sleep(1)
            # # 定位到用户名输入框并传值
            # self.driver.find_element_by_name('username').send_keys('Lmars')
            # #定位到密码输入框传值
            # self.driver.find_element_by_name('password').send_keys('123456')
            # # 定位到选择框并点击
            # self.driver.find_element_by_id('remember').click()
            # time.sleep(1)
            # # 定位到立即登录按钮并点击
            # self.driver.find_element_by_name('submit').click()

            time.sleep(1)
            # expect_text='Lmars'
            # actual_text=self.driver.find_element_by_xpath('/html/body/div[1]/div[2]/ul/li[1]/font/font/font').text
            # self.assertEqual(expect_text,actual_text,'使用Lmars/123456登录失败')
            # 定位到用户中心点击
            self.sub.test_usr_cen_btn()
            # self.driver.find_element_by_xpath('/html/body/div[1]/div[2]/ul/li[1]/font/font/a[1]').click()
            time.sleep(1)
            #定位到安全退出并点击
            self.sub.safe_quit()
            # self.driver.find_element_by_xpath('/html/body/div[7]/div[1]/div/div/div/div/a[14]/img').click()
            time.sleep(1)

        csv_file.close()