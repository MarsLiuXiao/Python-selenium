'''
@Project:Python
@Time:2019/4/30 15:17
@Author:Mars/liuxiao
'''

import unittest
import time
from selenium import webdriver


class TestDNF(unittest.TestCase):
    def setUp(self):
        self.driver=webdriver.Firefox()
        self.url='https://www.baidu.com/s?wd=dnf&rsv_spt=1&rsv_iqid=0xb9e8a6980007a229&issp=1&f=8&rsv_bp=1&rsv_idx=2&ie=utf-8&tn=baiduhome_pg&rsv_enter=1&rsv_sug3=2'
        self.driver.maximize_window()
        self.driver.delete_all_cookies()
    def tearDown(self):
        pass
        # self.driver.close()
    def test_dnf_navigate_001(self):
        self.driver.get(self.url)
        # time.sleep(1)
        # self.driver.find_element_by_id('kw').send_keys('dnf官网')
        # self.driver.find_element_by_id('su').click()
        # time.sleep(3)
        # all_window_handles=self.driver.window_handles
        # self.driver.switch_to.window(all_window_handles[1])
        self.driver.find_element_by_xpath('/html/body/div[1]/div[3]/div[1]/div[3]/div[1]/h3/a[1]').click()





