'''
@Project:Python
@Time:2019/4/29 18:10
@Author:Mars/liuxiao
'''
import time
from selenium import webdriver
# 浏览器实例化
driver=webdriver.Firefox()
#打开url
driver.get('http://localhost/wamp/www/ECShop_V2.7.2_b03/upload/')
time.sleep(1)
# 定位到登录按钮并点击
driver.find_element_by_xpath('/html/body/div[1]/div[2]/ul/li[1]/font/a[1]/img').click()
time.sleep(1)
# 定位到用户名输入框并传值
driver.find_element_by_name('username').send_keys('liuxiao')
#定位到密码输入框传值
driver.find_element_by_name('password').send_keys('123456')
# 定位到选择框并点击
driver.find_element_by_id('remember').click()
time.sleep(1)
# 定位到立即登录按钮并点击
driver.find_element_by_name('submit').click()
time.sleep(1)
driver.find_element_by_xpath('/html/body/div[1]/div[2]/ul/li[1]/font/font/a[1]').click()
time.sleep(1)
# 资金管理
driver.find_element_by_xpath('/html/body/div[7]/div[1]/div/div/div/div/a[13]').click()
# 充值
driver.find_element_by_xpath('/html/body/div[7]/div[2]/div/div/div/table[1]/tbody/tr/td/a[1]').click()
# 输入充值金额
driver.find_element_by_xpath('/html/body/div[7]/div[2]/div/div/div/form/table[1]/tbody/tr[1]/td[2]/input').send_keys('2000')
driver.find_element_by_name('user_note').send_keys('余额充值')



















