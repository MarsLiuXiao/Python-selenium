'''
@Project:Python
@Time:2019/4/29 15:21
@Author:Mars/liuxiao
'''
import unittest

from selenium import webdriver
import time

from page.sub_package.sub_page_user_cen_message001 import SubPageUserCenMessage

# driver=webdriver.Firefox()

# #浏览器是实例化
# driver=webdriver.Firefox()
# # 打开url
# driver.get('http://localhost/wamp/www/ECShop_V2.7.2_b03/upload/')
# time.sleep(1)
# # 全屏
# driver.maximize_window()
# # 点击登录按钮
# driver.find_element_by_xpath('/html/body/div[1]/div[2]/ul/li[1]/font/a[1]/img').click()
# time.sleep(1)
# # 用户名输入框
# driver.find_element_by_name('username').send_keys('liuxiao')
# # 密码输入框
# driver.find_element_by_name('password').send_keys('123456')
# #选中框
# driver.find_element_by_name('remember').click()
# time.sleep(1)
# # 点击登录按钮
# driver.find_element_by_name('submit').click()
# time.sleep(1)


# # 点击用户中心
# driver.find_element_by_xpath('/html/body/div[1]/div[2]/ul/li[1]/font/font/a[1]').click()
# # 点击我的留言
# driver.find_element_by_xpath('/html/body/div[7]/div[1]/div/div/div/div/a[6]').click()
# # 定位留言
# driver.find_element_by_xpath('/html/body/div[7]/div[2]/div/div/div/form/table/tbody/tr[1]/td[2]/input[1]').click()
# # 定位主题
# driver.find_element_by_xpath('/html/body/div[7]/div[2]/div/div/div/form/table/tbody/tr[2]/td[2]/input').send_keys('motto')
# # 定位留言内容
# driver.find_element_by_name('msg_content').send_keys('世界在脚下')
# # 上传文件
# driver.find_element_by_name('message_img').send_keys(r'C:\Users\EDZ\Desktop\001\a.txt')
# # 提交
# driver.find_element_by_xpath('/html/body/div[7]/div[2]/div/div/div/form/table/tbody/tr[5]/td[2]/input[2]').click()
# time.sleep(5)
# driver.close()


from AutoDriver.AutoDriver_001 import AutoDriver
import unittest
# 使用单元测试框架
from page.Common import Common


class TestMessage(unittest.TestCase):
    '''这是我的留言模块测试'''
    # driver= AutoDriver()
    def setUp(self):
        #实例化驱动类
        self.driver=AutoDriver()
        self.sub=SubPageUserCenMessage(self.driver)
        self.com_fun=Common(self.driver)
        self.com_fun.test_initialui()
        # #窗口最大化
        # self.driver.max_window()
        # #清除缓存
        # self.driver.del_cookies()
    def tearDown(self):

        #关闭所有页面，并退出浏览器驱动
        self.driver.quit_brower()
        # self.driver.quit_brower()

    def test_message(self):
        #打开url
        self.driver.open_url('/')
        # # 点击登录按钮
        # self.driver.find_element('xpath','/html/body/div[1]/div[2]/ul/li[1]/font/a[1]/img').click()
        # time.sleep(1)
        # # 用户名输入框
        # self.driver.find_element('name','username').send_keys('liuxiao')
        # # 密码输入框
        # self.driver.find_element('name','password').send_keys('123456')
        # #选中框
        # self.driver.find_element('name','remember').click()
        # time.sleep(1)
        # # 点击登录按钮
        # self.driver.find_element('name','submit').click()
        self.sub.test_login_btn()
        time.sleep(1)
        self.sub.test_login('liuxiao','123456')

        time.sleep(1)
        # 点击用户中心
        self.sub.test_usr_cen_btn()
        time.sleep(2)
        # self.driver.find_element('xpath','/html/body/div[1]/div[2]/ul/li[1]/font/font/a[1]').click()
        self.sub.test_message_module('moto','one product')
        time.sleep(1)
        # 断言留言是否成功
        #预期值
        # self.driver.bro_back()
        # expect_value='删除'
        # # 实际值
        # actual_value=self.driver.find_element('xpath','/html/body/div[7]/div[2]/div/div/div/div[6]/a').text
        # a= self.assertEqual(expect_value,actual_value,msg='留言失败')
        # print(a)
        time.sleep(1)
        # # 点击我的留言
        # self.driver.find_element('xpath','/html/body/div[7]/div[1]/div/div/div/div/a[6]').click()
        # # 定位留言
        # self.driver.find_element('xpath','/html/body/div[7]/div[2]/div/div/div/form/table/tbody/tr[1]/td[2]/input[1]').click()
        # # 定位主题
        # self.driver.find_element('xpath','/html/body/div[7]/div[2]/div/div/div/form/table/tbody/tr[2]/td[2]/input').send_keys('motto')
        # # 定位留言内容
        # self.driver.find_element('name','msg_content').send_keys('世界在脚下')
        # # 上传文件
        # self.driver.find_element('name','message_img').send_keys(r'C:\Users\EDZ\Desktop\001\a.txt')
        # # 提交
        # self.driver.find_element('xpath','/html/body/div[7]/div[2]/div/div/div/form/table/tbody/tr[5]/td[2]/input[2]').click()

