'''
@Project:Python
@Time:2019/4/30 17:02
@Author:Mars/liuxiao
'''
from selenium import webdriver
from selenium.webdriver.support.select import Select

class AutoDriver(object):
    def __init__(self):
        # 构造方法、初始化方法
        self.driver=webdriver.Firefox()
        self.base_url='http://localhost/wamp/www/ECShop_V2.7.2_b03/upload/'
          # 打开url

        #自定义方法：
    def open_url(self,url):
        self.driver.get(self.base_url+url)
        # 清除缓存
    def del_cookies(self):
        self.driver.delete_all_cookies()
    #     关闭浏览器
    def quit_brower(self):
        self.driver.quit()
    #     全屏打开
    def max_window(self):
        self.driver.maximize_window()
    #     八大定位
    def find_element(self,by,selector):
        if by=='id':
            return self.driver.find_element_by_id(selector)
        elif by=='name':
            return self.driver.find_element_by_name(selector)
        elif by=='xpath':
            return self.driver.find_element_by_xpath(selector)
        elif by=='class':
            return self.driver.find_element_by_class_name(selector)
        elif by=='link_txt':
            return  self.driver.find_element_by_link_text(selector)
        elif by=='partial_link_txt':
            return  self.driver.find_element_by_partial_link_text(selector)
        elif by=='tag':
            return self.driver.find_element_by_tag_name(selector)
        elif by=='css':
            return  self.driver.find_element_by_css_selector(selector)

    # 下拉框
    def select_box(self,by,find_mode,selector,value):
        if by=='index':
            return Select(self.driver.find_element(find_mode,selector)).select_by_index(value)
        if by=='value':
            return Select(self.driver.find_element(find_mode,selector)).select_by_value(value)
        if by=='vs_text':
            return  Select(self.driver.find_element(find_mode,selector)).select_by_visible_text(value)
    # 多表单
    def multi_frame(self,index,id):
        if index=='edge':
            return self.driver.switch_to.default_content()
        elif index=='back':
            return self.driver.switch_to.parent_frame()
        elif index=='direct':
            return self.driver.switch_to.frame(id)

    #多窗口句柄
    def multi_window(self):
        all_window_handles=self.driver.window_handles()
        current_window_handle=self.driver.current_window_handle()
        for handle in  all_window_handles:
            if handle==current_window_handle:
                handle=all_window_handles[1]
                return handle
    #上传文件的方式
    def file_load(self,u_mode,find_mode,selector,url):
        if u_mode==True:
            self.driver.find_element(find_mode,selector).send_keys(url)
        if u_mode==False:
            pass#使用autoit

    def bro_back(self):
        self.driver.back()



